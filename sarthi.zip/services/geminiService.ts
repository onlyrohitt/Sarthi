
import { GoogleGenAI, Modality, Type, Chat, GenerateContentResponse } from "@google/genai";

// Always use process.env.API_KEY directly as a named parameter.
const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

// Singleton to track and stop overlapping audio
let currentAudioSource: AudioBufferSourceNode | null = null;
let audioCtx: AudioContext | null = null;

/**
 * Interface for scheme with grounding
 */
export interface GroundedScheme {
  id: string;
  title: string;
  titleLocal: string;
  description: string;
  benefit: string;
  matchPercentage: number;
  department: string;
  nextSteps: string[];
  sources: { title: string; uri: string }[];
}

/**
 * Vision OCR: Advanced Label & Text Extraction (Cloud Vision Style)
 */
export async function extractDataFromId(base64Image: string, mimeType: string) {
  const ai = getAI();
  const prompt = `Perform high-precision Vision OCR and Label Detection on this Indian ID.
  1. IDENTIFY: Is this an Aadhar Card, PAN Card, or Ration Card?
  2. VERIFY: Is the text legible? Is it a genuine document?
  3. EXTRACT: Name, Date of Birth/Age, and Address/Location.
  4. METADATA: Provide detection labels for the UI.
  Return JSON only.`;
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        { inlineData: { data: base64Image, mimeType } },
        { text: prompt }
      ]
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          isValid: { type: Type.BOOLEAN },
          idType: { type: Type.STRING },
          confidenceScore: { type: Type.NUMBER },
          detectionLabels: { type: Type.ARRAY, items: { type: Type.STRING } },
          name: { type: Type.STRING },
          age: { type: Type.NUMBER },
          location: { type: Type.STRING }
        },
        required: ["isValid", "idType", "detectionLabels"]
      }
    }
  });

  return JSON.parse(response.text || '{}');
}

/**
 * TTS: Generate audio from text
 */
export async function speakText(text: string, language: string) {
  if (!text) return null;
  const ai = getAI();
  
  const voiceMap: Record<string, string> = {
    marathi: 'Kore',
    hindi: 'Puck',
    english: 'Zephyr'
  };

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voiceMap[language] || 'Puck' },
          },
        },
      },
    });

    const part = response.candidates?.[0]?.content?.parts?.[0];
    const base64Audio = part?.inlineData?.data;
    return base64Audio || null;
  } catch (e) {
    console.error("TTS generation failed", e);
    return null;
  }
}

/**
 * Match profile to schemes using Search Grounding
 */
export async function matchSchemes(profile: any, language: string): Promise<GroundedScheme[]> {
  const ai = getAI();
  const prompt = `Find 4 active government schemes for a citizen with this profile: ${JSON.stringify(profile)}. Location: ${profile.location}. Language: ${language}. Return JSON.`;
  
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      tools: [{ googleSearch: {} }],
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            id: { type: Type.STRING },
            title: { type: Type.STRING },
            titleLocal: { type: Type.STRING },
            description: { type: Type.STRING },
            benefit: { type: Type.STRING },
            matchPercentage: { type: Type.NUMBER },
            department: { type: Type.STRING },
            nextSteps: { type: Type.ARRAY, items: { type: Type.STRING } }
          }
        }
      }
    }
  });

  const schemes: any[] = JSON.parse(response.text || '[]');
  const sources: { title: string; uri: string }[] = [];
  const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
  if (groundingChunks) {
    groundingChunks.forEach((chunk: any) => {
      if (chunk.web?.uri && chunk.web?.title) {
        sources.push({ title: chunk.web.title, uri: chunk.web.uri });
      }
    });
  }

  return schemes.map(s => ({ ...s, sources }));
}

/**
 * Dialogflow-style Intent Manager
 */
export function createSchemeChat(scheme: any, profile: any, language: string): Chat {
  const ai = getAI();
  return ai.chats.create({
    model: 'gemini-3-flash-preview',
    config: {
      tools: [{ googleSearch: {} }],
      systemInstruction: `You are the Sarthi Dialogflow Agent for the scheme: "${scheme.titleLocal}".
      USER PROFILE: ${JSON.stringify(profile)}.
      TARGET LANGUAGE: ${language}.
      
      INTENT HANDLING:
      - ELIGIBILITY: If the user asks if they can apply, check their profile and give a clear Yes/No.
      - DOCUMENTS: List exactly what is needed based on current rules.
      - APPLICATION: Describe the step-by-step process.
      - GREETING: Be warm and helpful.
      
      Maintain context and guide the citizen with empathy. Reply ONLY in ${language}.`,
    },
  });
}

/**
 * Audio player helper
 */
export async function playBase64Audio(base64: string) {
  try {
    if (currentAudioSource) {
      currentAudioSource.stop();
      currentAudioSource = null;
    }

    const binaryString = atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }

    if (!audioCtx) {
      audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    }
    
    if (audioCtx.state === 'suspended') {
      await audioCtx.resume();
    }

    const dataInt16 = new Int16Array(bytes.buffer);
    const frameCount = dataInt16.length;
    const buffer = audioCtx.createBuffer(1, frameCount, 24000);
    const channelData = buffer.getChannelData(0);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i] / 32768.0;
    }

    const source = audioCtx.createBufferSource();
    source.buffer = buffer;
    source.connect(audioCtx.destination);
    
    currentAudioSource = source;
    source.start();
  } catch (e) {
    console.error("Audio playback error", e);
  }
}

export function stopAllSpeech() {
  if (currentAudioSource) {
    try {
      currentAudioSource.stop();
    } catch(e) {}
    currentAudioSource = null;
  }
}

export async function generateProfileSummary(profile: any, language: string): Promise<string> {
  const ai = getAI();
  const prompt = `Confirm details: ${profile.name}, age ${profile.age}, at ${profile.location} in ${language}. Ask if correct. Very short.`;
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: { temperature: 0.1, maxOutputTokens: 60 }
  });
  return response.text?.trim() || '';
}
